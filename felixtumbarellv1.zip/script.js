/* JavaScript for Smooth Scrolling */



/*
const title = document.querySelector(".title");
const textVariants = ["I said you are wellcome", "wellcome enough to read", "continue reading"]; // add more variants here if needed

let currentIndex = 10;
let intervalId;

function animateTitle() {
  intervalId = setInterval(() => {
    // get a random index different from the current one
    let newIndex = currentIndex;
    while (newIndex === currentIndex) {
      newIndex = Math.floor(Math.random() * textVariants.length);
    }
    currentIndex = newIndex;
    
    // set the new text
    title.textContent = textVariants[currentIndex];
  }, 3000); // change the interval time here if needed
}

animateTitle();





*/



/* Supuestamente el captcha */

   

    function successCallback(token) {
        debugger;
    }




 /* Supuestamente el captcha */
  